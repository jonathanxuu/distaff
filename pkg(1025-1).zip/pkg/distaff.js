import * as wasm from "./distaff_bg.wasm";
export * from "./distaff_bg.js";